"""
analyse_motors.py - turns motor_log.txt (copied from the Serial Monitor) into
the figures, tidy CSV files and the numbers for the report.
SEMTM0043/42 Individual report - student 2751176

Usage:   python analyse_motors.py motor_log.txt
Needs:   numpy, matplotlib   (pip install numpy matplotlib)

Outputs
  fig1_deadband_hysteresis.png  wheel speed vs signed PWM (lifted), start/stop PWM
  fig2_encoder_cpr.png          counts per revolution per trial vs documented 358.3
  fig3_encoder_calibration.png  distance vs counts (only if test c data exists)
  data_*.csv, results_summary.txt
"""
import csv
import sys

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

LEFT_C, RIGHT_C = "#1f5fa8", "#c23b22"
STEP_S = 0.300                    # DB_STEP_MS in MotorTest.h
DOC_CPR = 358.3                   # documented in i2c_datatypes.h
COND = {1: "floor", 2: "lifted"}
plt.rcParams.update({"font.size": 7.5, "font.family": "DejaVu Sans"})


def parse_log(path):
    rows = {"DBR": [], "DBS": [], "ENC": [], "CAL": []}
    with open(path, encoding="utf-8", errors="ignore") as f:
        for line in f:
            p = line.strip().split(",")
            if p[0] in rows:
                try:
                    rows[p[0]].append([float(x) for x in p[1:]])
                except ValueError:
                    pass
    return {k: np.array(v) for k, v in rows.items()}


def write_csv(name, header, data):
    with open(name, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(header)
        w.writerows(np.asarray(data).tolist())


def msd(x):
    x = np.asarray(x, float)
    x = x[x >= 0]
    if len(x) == 0:
        return np.nan, np.nan, 0
    return x.mean(), (x.std(ddof=1) if len(x) > 1 else 0.0), len(x)


def main(path):
    d = parse_log(path)
    out = []

    # ---------------- deadband summary ----------------------------------------
    db = {}
    if len(d["DBS"]):
        s = d["DBS"]          # cond, dir, up, trial, uL, uR
        write_csv("data_deadband.csv", ["cond(1=floor,2=lifted)", "dir", "up(1=start,0=stop)", "trial", "pwm_left", "pwm_right"], s)
        write_csv("data_deadband_raw.csv", ["cond", "dir", "up", "trial", "pwm", "step_counts_left", "step_counts_right"], d["DBR"])
        out.append("DEADBAND (PWM in setMotorPWM units; mean +/- SD, n)")
        for cond in (2, 1):
            for di, dn in ((1, "forward"), (-1, "backward")):
                for up, un in ((1, "start"), (0, "stop ")):
                    sel = s[(s[:, 0] == cond) & (s[:, 1] == di) & (s[:, 2] == up)]
                    if not len(sel):
                        continue
                    line = f"  {COND[cond]:6s} {dn:8s} {un}:"
                    for col, w in ((4, "left"), (5, "right")):
                        db[(cond, di, up, w)] = msd(sel[:, col])
                        m, sd, n = db[(cond, di, up, w)]
                        line += f"  {w} {m:5.1f} +/- {sd:3.1f} (n={n}, trials {sel[:, col].astype(int).tolist()})"
                    out.append(line)

    # ---------------- speed vs PWM from the ramps --------------------------------
    b = d["DBR"]
    curves = {}
    if len(b):
        out.append("SPEED vs PWM (lifted, ramp down = wheel already moving; counts/s)")
        for di in (1, -1):
            for w, col in (("left", 5), ("right", 6)):
                for up in (0, 1):
                    sel = b[(b[:, 0] == 2) & (b[:, 1] == di) & (b[:, 2] == up)]
                    if not len(sel):
                        continue
                    pw = np.unique(sel[:, 4])
                    v = np.array([np.mean(np.abs(sel[sel[:, 4] == p][:, col])) / STEP_S for p in pw])
                    curves[(di, w, up)] = (pw, v)
                pw, v = curves[(di, w, 0)]
                m = pw >= db.get((2, di, 0, w), (0,))[0] + 4      # clearly moving region
                k, c0 = np.polyfit(pw[m], v[m], 1)
                r2 = 1 - np.sum((v[m] - (k * pw[m] + c0)) ** 2) / np.sum((v[m] - v[m].mean()) ** 2)
                st = db.get((2, di, 1, w), (np.nan,))[0]
                v_at_start = k * st + c0
                out.append(f"  {'fwd' if di > 0 else 'bwd'} {w:5s}: k = {k:.2f} counts/s per PWM, zero at PWM {-c0 / k:.1f}, "
                           f"R^2 = {r2:.4f}; speed at start PWM ({st:.1f}) = {v_at_start:.0f} counts/s "
                           f"= {v_at_start / DOC_CPR:.2f} rev/s; v@50 = {np.interp(50, pw, v):.0f}")

        fig, ax = plt.subplots(figsize=(4.2, 2.55), dpi=220)
        for w, colr in (("left", LEFT_C), ("right", RIGHT_C)):
            for di in (1, -1):
                if (di, w, 0) in curves:
                    pw, v = curves[(di, w, 0)]
                    ax.plot(di * pw, di * v, "-", color=colr, lw=1.2,
                            label=f"{w}: slowing (moving)" if di == 1 else None)
                if (di, w, 1) in curves:
                    pw, v = curves[(di, w, 1)]
                    ax.plot(di * pw, di * v, "--", color=colr, lw=0.8, alpha=0.7,
                            label=f"{w}: speeding up from rest" if di == 1 else None)
                st = db.get((2, di, 1, w)); sp = db.get((2, di, 0, w))
                yoff = 25 if w == "left" else -25
                if st:
                    ax.errorbar(di * st[0], yoff, xerr=st[1], fmt="o", color=colr, ms=3.5, capsize=2, lw=0.8)
                if sp:
                    ax.errorbar(di * sp[0], yoff, xerr=sp[1], fmt="o", mfc="white", color=colr, ms=3.5, capsize=2, lw=0.8)
        ax.axhline(0, color="0.6", lw=0.5)
        ax.axvline(0, color="0.6", lw=0.5)
        ax.plot([], [], "ko", ms=3.5, label="start PWM (mean ± SD)")
        ax.plot([], [], "o", mfc="white", color="k", ms=3.5, label="stop PWM")
        ax.set_xlabel("PWM command (setMotorPWM units; negative = backwards)")
        ax.set_ylabel("Wheel speed (encoder counts/s)")
        ax.legend(fontsize=6, frameon=False, loc="upper left", ncol=1)
        ax.grid(alpha=0.25)
        fig.tight_layout(pad=0.3)
        fig.savefig("fig1_deadband_hysteresis.png")
        out.append("Saved fig1_deadband_hysteresis.png")

    # ---------------- encoders: counts per revolution ----------------------------
    if len(d["ENC"]):
        e = d["ENC"]          # wheel, trial, revs, cl, cr
        write_csv("data_encoder_rev.csv", ["wheel(0=left,1=right)", "trial", "revs", "left_counts", "right_counts"], e)
        out.append("ENCODER COUNTS PER REVOLUTION (documented 358.3)")
        fig, ax = plt.subplots(figsize=(4.2, 1.45), dpi=220)
        for w, name, col, colr, x0 in ((0, "left", 3, LEFT_C, 0), (1, "right", 4, RIGHT_C, 1)):
            sel = e[e[:, 0] == w]
            named, other = np.abs(sel[:, col]), np.abs(sel[:, 7 - col])
            valid = named > 0.5 * np.maximum(other, 1)          # wrong wheel turned -> excluded
            cpr = sel[:, col] / sel[:, 2]
            for t, ok in zip(sel[:, 1], valid):
                if not ok:
                    out.append(f"  {name} trial {int(t)} EXCLUDED: named wheel did not turn (other wheel moved)")
            m, sd, n = msd(np.abs(cpr[valid]))
            sign = "positive (OK)" if np.all(cpr[valid] > 0) else "NEGATIVE"
            out.append(f"  {name}: {m:.1f} +/- {sd:.1f} counts/rev (n={n}, trials {np.round(cpr[valid], 1).tolist()}), "
                       f"{100 * (m / DOC_CPR - 1):+.2f}% vs documented, sign {sign}")
            ax.plot(cpr[valid], np.full(valid.sum(), x0), "o", color=colr, ms=4, alpha=0.85)
            ax.plot([m], [x0], "|", color="k", ms=10, mew=1.2)
        ax.axvline(DOC_CPR, color="0.3", ls="--", lw=0.9)
        ax.text(DOC_CPR, 1.45, " documented 358.3", fontsize=6.5, va="center", color="0.3")
        ax.set_yticks([0, 1], ["left", "right"])
        ax.set_ylim(-0.6, 1.7)
        ax.set_xlabel("Encoder counts per wheel revolution")
        ax.grid(alpha=0.25, axis="x")
        fig.tight_layout(pad=0.3)
        fig.savefig("fig2_encoder_cpr.png")
        out.append("Saved fig2_encoder_cpr.png")

    # ---------------- encoders: distance per count ------------------------------
    if len(d["CAL"]):
        cal = d["CAL"]        # trial, ms, dl, dr, dist
        c_mean = (np.abs(cal[:, 2]) + np.abs(cal[:, 3])) / 2
        dist = cal[:, 4]
        slope, icpt = np.polyfit(c_mean, dist, 1)
        pred = slope * c_mean + icpt
        r2 = 1 - np.sum((dist - pred) ** 2) / np.sum((dist - dist.mean()) ** 2)
        write_csv("data_calibration.csv", ["trial", "drive_ms", "left_counts", "right_counts", "distance_mm", "mean_counts"],
                  np.column_stack([cal, c_mean]))
        out.append("ENCODER DISTANCE CALIBRATION")
        out.append(f"  distance = {slope:.4f} mm/count x counts + {icpt:.1f} mm, R^2 = {r2:.4f} (n={len(cal)})")
        out.append(f"  counts for 10 cm (beep) = {100 / slope:.0f}")
        fig, ax = plt.subplots(figsize=(4.2, 1.9), dpi=220)
        ax.plot(c_mean, dist, "ko", ms=3.5)
        xs = np.linspace(0, c_mean.max() * 1.05, 50)
        ax.plot(xs, slope * xs + icpt, "k-", lw=0.9, label=f"fit: {slope:.4f} mm/count")
        ax.set_xlabel("Encoder counts (mean of both wheels)")
        ax.set_ylabel("Distance (mm)")
        ax.legend(fontsize=6.5, frameon=False)
        ax.grid(alpha=0.25)
        fig.tight_layout(pad=0.3)
        fig.savefig("fig3_encoder_calibration.png")
        out.append("Saved fig3_encoder_calibration.png")
    else:
        out.append("No CAL lines yet - run test c for mm per count.")

    print("\n".join(out))
    with open("results_summary.txt", "w") as f:
        f.write("\n".join(out) + "\n")


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "motor_log.txt")
