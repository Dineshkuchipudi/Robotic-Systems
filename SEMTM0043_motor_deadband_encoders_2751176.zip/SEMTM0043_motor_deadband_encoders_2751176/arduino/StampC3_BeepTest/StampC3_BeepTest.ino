#include <Wire.h>

#include "RobotWifiAP.h"
RobotWifiAP_c server("myAP", "myPassword", 80);

#include "Robot.h"
#include "RobotIMU.h"
#include "Controller.h"

Robot_c robot;
RobotIMU_c imu;
Controller_c controller;

#include "PathEvents.h"     // beep every 10 cm, blink on turns

void setup() {
  Serial.begin(115200);
  delay(2000);
  Serial.println("1. setup started");

  server.begin();
  robot.initialise();
  if (!imu.initialise()) {
    Serial.println("Warning: LSM6DS33 IMU was not detected.");
  }

  // buzzer check: you should hear one beep now
  bool ok = robot.playTone(1000, 300);
  Serial.println(ok ? "2. buzzer test sent (you should hear a beep)"
                    : "2. buzzer test FAILED - is the 3pi+ switched on?");

  pathEventsBegin();
  Serial.println("3. Push the robot slowly along a tape: it beeps every 10 cm.");
}

void loop() {
  robot.getEncoders();   // fetch fresh encoder counts from the 3pi+
  pathEventsUpdate();    // beep every 10 cm, blink while turning
  delay(20);
}
