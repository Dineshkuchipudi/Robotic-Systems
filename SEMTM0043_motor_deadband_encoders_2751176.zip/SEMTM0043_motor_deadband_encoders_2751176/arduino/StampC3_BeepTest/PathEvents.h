// ============================================================================
//  PathEvents.h  -  Path reproduction feedback (StampC3 + 3pi+)
//    * BEEP every 10 cm the robot travels  (3pi+ buzzer: robot.playTone)
//    * BLINK the StampC3 LED while turning  (robot.setLED)
//  Distance and turning come from the wheel encoders only.
//  Motors / encoders part - student 2751176
//
//  HOW TO USE (after the motor tests are finished)
//  1. Put this file in the sketch folder (new tab "PathEvents.h").
//  2. In StampC3_Template.ino, under  Controller_c controller;  add:
//          #include "PathEvents.h"
//  3. At the end of setup():            pathEventsBegin();
//  4. In loop(), right AFTER controller.update(robot, server);  add:
//          pathEventsUpdate();
//  5. When a recording or replay starts, call:  pathEventsReset();
//
//  SET PE_MM_PER_COUNT TO YOUR OWN RESULT FROM TEST c BEFORE USING.
// ============================================================================
#ifndef PATH_EVENTS_H
#define PATH_EVENTS_H

// ---- your measured value (Motortest "c" -> RESULT MM PER COUNT) ----
const float PE_MM_PER_COUNT = 0.0f;      // <-- REQUIRED. Beeps stay off while 0.

// ---- encoder refresh ----
// false: use the counts the controller already fetched with getEncoders()
//        (safest: does not disturb your team's odometry, which uses last_encoders)
// true : PathEvents calls robot.getEncoders() itself (only if nothing else does)
const bool PE_CALL_GET_ENCODERS = false;

// ---- behaviour ----
const float PE_BEEP_EVERY_MM    = 100.0f;  // 10 cm
const uint16_t PE_BEEP_FREQ_HZ  = 2000;
const uint16_t PE_BEEP_MS       = 60;
const unsigned long PE_CHECK_MS = 100;     // turn check window
const float PE_TURN_RATIO       = 0.30f;   // wheels differ by >30% -> turning
const long  PE_MIN_COUNTS       = 20;      // ignore tiny movement / standing still
const unsigned long PE_BLINK_MS = 150;     // LED on/off time while turning
const bool  PE_DEBUG            = true;    // print "# BEEP ..." lines (set false when
                                           // the Digital Twin reads the serial port)

// ---------------- internal state ----------------
static long  pe_lastL = 0, pe_lastR = 0, pe_winL = 0, pe_winR = 0;
static float pe_dist_mm = 0, pe_nextBeep_mm = PE_BEEP_EVERY_MM;
static unsigned long pe_lastCheck = 0, pe_lastBlink = 0;
static bool  pe_turning = false, pe_ledOn = false;
static int   pe_turnCount = 0;

static void pe_led(bool on) {
  pe_ledOn = on;
  if (on) robot.setLED(255, 120, 0, 120);   // orange
  else    robot.setLED(0, 0, 0, 0);         // off
}

void pathEventsReset() {
  pe_lastL = pe_winL = (long)robot.getLeftEncoderCount();
  pe_lastR = pe_winR = (long)robot.getRightEncoderCount();
  pe_dist_mm = 0;
  pe_nextBeep_mm = PE_BEEP_EVERY_MM;
  pe_turning = false;
  pe_turnCount = 0;
  pe_led(false);
}

void pathEventsBegin() {
  robot.getEncoders();
  pathEventsReset();
  pe_lastCheck = millis();
  if (PE_MM_PER_COUNT <= 0)
    Serial.println("# WARNING: PE_MM_PER_COUNT is 0 - set it in PathEvents.h, beeps are OFF");
}

void pathEventsUpdate() {
  unsigned long now = millis();
  if (PE_CALL_GET_ENCODERS) robot.getEncoders();
  long cl = (long)robot.getLeftEncoderCount(), cr = (long)robot.getRightEncoderCount();

  // ---- 1. distance travelled by the robot centre -> beep every 10 cm ----
  long dl = cl - pe_lastL, dr = cr - pe_lastR;
  pe_lastL = cl; pe_lastR = cr;
  pe_dist_mm += fabsf(PE_MM_PER_COUNT * (dl + dr) * 0.5f);   // a spin on the spot adds ~0
  if (PE_MM_PER_COUNT > 0 && pe_dist_mm >= pe_nextBeep_mm) {
    robot.playTone(PE_BEEP_FREQ_HZ, PE_BEEP_MS);             // the 3pi+ times the beep
    if (PE_DEBUG) Serial.printf("# BEEP at %.0f mm\n", pe_dist_mm);
    pe_nextBeep_mm += PE_BEEP_EVERY_MM;
  }

  // ---- 2. turning? compare the two wheels over a short window ----
  if (now - pe_lastCheck >= PE_CHECK_MS) {
    long wl = cl - pe_winL, wr = cr - pe_winR;
    pe_winL = cl; pe_winR = cr;
    pe_lastCheck = now;
    long moved = (labs(wl) + labs(wr)) / 2;
    bool turning = (moved >= PE_MIN_COUNTS) && (labs(wr - wl) > PE_TURN_RATIO * moved);
    if (turning && !pe_turning) {
      pe_turnCount++;
      if (PE_DEBUG) Serial.printf("# TURN %d started - LED blinking\n", pe_turnCount);
    }
    if (!turning && pe_turning) pe_led(false);
    pe_turning = turning;
  }

  // ---- 3. blink while turning ----
  if (pe_turning && now - pe_lastBlink >= PE_BLINK_MS) {
    pe_lastBlink = now;
    pe_led(!pe_ledOn);
  }
}

#endif
