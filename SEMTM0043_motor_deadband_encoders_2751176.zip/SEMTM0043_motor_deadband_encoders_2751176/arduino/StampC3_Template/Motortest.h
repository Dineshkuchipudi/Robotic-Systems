// ============================================================================
//  Motortest.h  -  Motor DEADBAND and WHEEL ENCODER tests (StampC3 + 3pi+)
//  SEMTM0043/42 Individual report - student 2751176
//  Uses the template's own Robot_c functions: setMotorPWM(), getEncoders(),
//  getLeftEncoderCount(), getRightEncoderCount().
//
//  Serial Monitor: 115200 baud, "New Line". Type a letter + Enter:
//    e = live ENCODER check (10 s) - turn the wheels by hand, counts must change
//    d = DEADBAND: start PWM (ramp up) and stop PWM (ramp down)
//    r = counts per wheel REVOLUTION (turn each wheel 10 times by hand)
//    c = mm per count CALIBRATION (robot drives, you measure with a tape)
//
//  THIS FILE MUST NOT CONTAIN  #include "Motortest.h"  (that line goes in the .ino)
// ============================================================================
#ifndef MOTOR_TEST_H
#define MOTOR_TEST_H

// ---------------- settings --------------------------------------------------------
const int  DB_MAX_PWM     = 150;   // ramp up stops here if a wheel never moves
const long DB_STEP_MS     = 300;   // time at each PWM value
const int  DB_MOVE_COUNTS = 2;     // >= this many counts in one step = "moving"
const int  DB_DOWN_MARGIN = 15;    // ramp down starts this far above the start PWM
const int  TRIALS_DB      = 5;
const int  REV_TURNS      = 10;
const int  TRIALS_REV     = 3;
const long CAL_TIMES_MS[] = {1000, 2000, 3000, 4000};
const int  TRIALS_CAL     = 3;

// ---------------- robot access (exact template functions) ------------------------
static long mt_failCount = 0;

static void mtSetPWM(int l, int r) { robot.setMotorPWM((float)l, (float)r); }
static void mtStop() { mtSetPWM(0, 0); }

// Asks the 3pi+ for a fresh encoder snapshot, then returns both counts.
static bool mtReadEncoders(long &left, long &right) {
  bool ok = robot.getEncoders();
  if (!ok) mt_failCount++;
  left  = (long)robot.getLeftEncoderCount();
  right = (long)robot.getRightEncoderCount();
  return ok;
}

static void mtWait(unsigned long ms) {
  unsigned long t0 = millis();
  while (millis() - t0 < ms) delay(1);
}

static void mtReportFailures() {
  if (mt_failCount > 0) {
    Serial.printf("# WARNING: %ld encoder reads FAILED (3pi+ did not answer over I2C).\n", mt_failCount);
    Serial.println("#          Check the 3pi+ is switched ON and the StampC3 is seated firmly.");
  }
  mt_failCount = 0;
}

// ---------------- maths and printing ------------------------------------------------
static void mtMeanSD(const float *v, int n, float &mean, float &sd, int &used) {
  float s = 0, s2 = 0; used = 0;
  for (int i = 0; i < n; i++) if (v[i] >= 0) { s += v[i]; s2 += v[i] * v[i]; used++; }
  mean = used ? s / used : -1;
  sd = used > 1 ? sqrtf(fmaxf(0, (s2 - used * mean * mean) / (used - 1))) : 0;
}
static void mtPrintResult(const char *label, const float *vl, const float *vr, int n) {
  float ml, sl, mr, sr; int nl, nr;
  mtMeanSD(vl, n, ml, sl, nl);
  mtMeanSD(vr, n, mr, sr, nr);
  Serial.printf("# RESULT %-26s LEFT %7.1f +/- %5.1f (n=%d)   RIGHT %7.1f +/- %5.1f (n=%d)\n",
                label, ml, sl, nl, mr, sr, nr);
}

// waits for a typed number + Enter. Empty lines (a stray Enter) are ignored.
static float mtReadNumber(const char *prompt) {
  delay(50);
  while (Serial.available()) Serial.read();
  Serial.printf("# %s then press Enter:\n", prompt);
  char buf[24]; int n = 0;
  while (true) {
    if (!Serial.available()) { delay(5); continue; }
    char ch = Serial.read();
    if (ch == '\n' || ch == '\r') { if (n == 0) continue; break; }
    if (n < (int)sizeof(buf) - 1) buf[n++] = ch;
  }
  buf[n] = 0;
  float v = atof(buf);
  Serial.printf("# you typed %.1f\n", v);
  return v;
}

// ---------------- test e: live encoder check -----------------------------------------
static void testEncoderLive() {
  Serial.println("# TEST e: motors OFF. Turn the wheels by hand for 10 s - the counts must change.");
  mtStop();
  long l, r;
  unsigned long t0 = millis();
  while (millis() - t0 < 10000) {
    bool ok = mtReadEncoders(l, r);
    Serial.printf("#   left %7ld   right %7ld   %s\n", l, r, ok ? "" : "<-- read FAILED");
    mtWait(250);
  }
  mtReportFailures();
  Serial.println("# TEST e done");
}

// ---------------- test d: deadband ------------------------------------------------
// One ramp. up: 0 -> DB_MAX_PWM, first PWM where each wheel MOVES.
//           down: startPWM -> 0, first PWM where each wheel STOPS.
static void mtRamp(int cond, int dir, bool up, int trial, int downFrom, float *outL, float *outR) {
  int uL = -1, uR = -1;
  long l0, r0, l1, r1;
  if (!up) { mtSetPWM(dir * downFrom, dir * downFrom); mtWait(1000); }   // get moving first
  int u = up ? 0 : downFrom;
  while (up ? (u <= DB_MAX_PWM) : (u >= 0)) {
    mtSetPWM(dir * u, dir * u);
    mtReadEncoders(l0, r0);
    mtWait(DB_STEP_MS);
    mtReadEncoders(l1, r1);
    long sl = l1 - l0, sr = r1 - r0;                       // counts during this step
    Serial.printf("DBR,%d,%d,%d,%d,%d,%ld,%ld\n", cond, dir, up ? 1 : 0, trial, u, sl, sr);
    bool movL = labs(sl) >= DB_MOVE_COUNTS, movR = labs(sr) >= DB_MOVE_COUNTS;
    if (up) { if (uL < 0 && movL) uL = u;  if (uR < 0 && movR) uR = u; }
    else    { if (uL < 0 && !movL) uL = u; if (uR < 0 && !movR) uR = u; }
    if (uL >= 0 && uR >= 0) break;
    u += up ? 1 : -1;
  }
  mtStop();
  Serial.printf("DBS,%d,%d,%d,%d,%d,%d\n", cond, dir, up ? 1 : 0, trial, uL, uR);
  Serial.printf("#   trial %d %s %s: LEFT %d  RIGHT %d\n", trial, dir > 0 ? "forward" : "backward",
                up ? "START PWM" : "STOP PWM", uL, uR);
  *outL = uL; *outR = uR;
  mtWait(800);
}

static void testDeadband() {
  int cond = (int)mtReadNumber("Type 1 = robot ON THE FLOOR (needs ~1 m clear), 2 = WHEELS LIFTED");
  if (cond != 1 && cond != 2) { Serial.println("# cancelled"); return; }
  Serial.println("# TEST d: DBR,cond,dir,up,trial,pwm,step_counts_left,step_counts_right (raw)");
  Serial.println("#         DBS,cond,dir,up,trial,pwm_left,pwm_right (up=1 START, up=0 STOP, -1 = not found)");
  float stL[2][TRIALS_DB], stR[2][TRIALS_DB], spL[2][TRIALS_DB], spR[2][TRIALS_DB];
  for (int di = 0; di < 2; di++) {
    int dir = di == 0 ? 1 : -1;
    for (int k = 1; k <= TRIALS_DB; k++) {
      mtRamp(cond, dir, true, k, 0, &stL[di][k - 1], &stR[di][k - 1]);
      int start = (int)fmaxf(stL[di][k - 1], stR[di][k - 1]);
      if (start < 0) { Serial.println("# a wheel never started - skipping stop test"); spL[di][k-1] = spR[di][k-1] = -1; continue; }
      int from = min(start + DB_DOWN_MARGIN, DB_MAX_PWM);
      mtRamp(cond, dir, false, k, from, &spL[di][k - 1], &spR[di][k - 1]);
    }
  }
  const char *c = cond == 1 ? "FLOOR" : "LIFTED";
  char lab[40];
  Serial.println("# ================= DEADBAND RESULTS =================");
  snprintf(lab, sizeof lab, "%s forward  START PWM", c); mtPrintResult(lab, stL[0], stR[0], TRIALS_DB);
  snprintf(lab, sizeof lab, "%s forward  STOP PWM",  c); mtPrintResult(lab, spL[0], spR[0], TRIALS_DB);
  snprintf(lab, sizeof lab, "%s backward START PWM", c); mtPrintResult(lab, stL[1], stR[1], TRIALS_DB);
  snprintf(lab, sizeof lab, "%s backward STOP PWM",  c); mtPrintResult(lab, spL[1], spR[1], TRIALS_DB);
  Serial.println("# Deadband = 0 up to the START PWM (motor powered, wheel not turning)");
  Serial.println("# ====================================================");
  mtReportFailures();
  Serial.println("# TEST d done");
}

// ---------------- test r: counts per wheel revolution --------------------------------
static void testRevolution() {
  mtStop();
  Serial.println("# TEST r: put a tape mark on the tyre. Motors are OFF. (documented: 358.3 counts/rev)");
  Serial.println("# columns: ENC,wheel(0=left,1=right),trial,revs,left_counts,right_counts");
  float cprL[TRIALS_REV], cprR[TRIALS_REV];
  long l0, r0, l1, r1;
  for (int w = 0; w <= 1; w++)
    for (int k = 1; k <= TRIALS_REV; k++) {
      mtReadNumber(w == 0 ? "LEFT wheel: line up the mark, type 1" : "RIGHT wheel: line up the mark, type 1");
      mtReadEncoders(l0, r0);
      mtReadNumber("Now turn that wheel FORWARDS exactly 10 full turns by hand, type 1");
      mtReadEncoders(l1, r1);
      long dl = l1 - l0, dr = r1 - r0;
      Serial.printf("ENC,%d,%d,%d,%ld,%ld\n", w, k, REV_TURNS, dl, dr);
      float cpr = (float)(w == 0 ? dl : dr) / REV_TURNS;
      Serial.printf("#   trial %d %s wheel: %.1f counts per revolution%s\n", k, w == 0 ? "LEFT" : "RIGHT", cpr,
                    cpr < 0 ? "  <-- NEGATIVE: encoder counts backwards" : "");
      if (w == 0) cprL[k - 1] = fabsf(cpr); else cprR[k - 1] = fabsf(cpr);
    }
  Serial.println("# ================= ENCODER RESULTS =================");
  mtPrintResult("COUNTS PER REVOLUTION", cprL, cprR, TRIALS_REV);
  Serial.println("# (documented value in i2c_datatypes.h: 358.3 counts per revolution)");
  Serial.println("# ====================================================");
  mtReportFailures();
  Serial.println("# TEST r done");
}

// ---------------- test c: distance per count ------------------------------------------
static void testCalibration() {
  Serial.println("# TEST c: lay a tape measure on the floor. Robot drives straight.");
  int pwm = (int)mtReadNumber("Type the PWM to drive at (your START PWM + about 20)");
  if (pwm <= 0) { Serial.println("# cancelled"); return; }
  Serial.println("# columns: CAL,trial,drive_ms,left_counts,right_counts,distance_mm");
  const int NT = (int)(sizeof(CAL_TIMES_MS) / sizeof(CAL_TIMES_MS[0]));
  const int NCAL = TRIALS_CAL * NT;
  float mmMean[NCAL];
  int n = 0;
  long l0, r0, l1, r1;
  for (int k = 1; k <= TRIALS_CAL; k++)
    for (int i = 0; i < NT; i++) {
      mtReadNumber("Put robot at the tape zero, facing along the tape, type 1");
      mtReadEncoders(l0, r0);
      mtSetPWM(pwm, pwm);
      mtWait(CAL_TIMES_MS[i]);
      mtStop();
      mtWait(500);
      mtReadEncoders(l1, r1);
      long dl = l1 - l0, dr = r1 - r0;
      float d = mtReadNumber("Measure the distance travelled in mm (same point on the robot), type it");
      Serial.printf("CAL,%d,%ld,%ld,%ld,%.1f\n", n + 1, CAL_TIMES_MS[i], dl, dr, d);
      mmMean[n] = (labs(dl) + labs(dr)) ? d / ((labs(dl) + labs(dr)) / 2.0f) : -1;
      Serial.printf("#   run %d: %.1f mm, LEFT %ld, RIGHT %ld counts -> %.4f mm per count\n",
                    n + 1, d, dl, dr, mmMean[n]);
      n++;
    }
  float m, sd; int used;
  mtMeanSD(mmMean, n, m, sd, used);
  Serial.println("# ================= ENCODER RESULTS =================");
  Serial.printf("# RESULT MM PER COUNT                 %.4f +/- %.4f (n=%d)\n", m, sd, used);
  if (m > 0) Serial.printf("# RESULT COUNTS FOR 10 cm (beep)      %.0f\n", 100.0f / m);
  Serial.println("# ====================================================");
  mtReportFailures();
  Serial.println("# TEST c done");
}

// ---------------- call this at the top of loop() --------------------------------------
void motorTestLoop() {
  static bool first = true;
  static unsigned long lastMsg = 0;
  bool showNow = first;
  if (first) { mtStop(); first = false; }
  if (showNow || millis() - lastMsg > 3000) {
    lastMsg = millis();
    Serial.println("# MotorTest ready. Type e, d, r or c and press Enter.");
  }
  if (!Serial.available()) { delay(5); return; }
  char cmd = Serial.read();
  if (cmd == '\n' || cmd == '\r' || cmd == ' ') return;
  delay(50);
  while (Serial.available()) Serial.read();
  switch (cmd) {
    case 'e': testEncoderLive();  break;
    case 'd': testDeadband();     break;
    case 'r': testRevolution();   break;
    case 'c': testCalibration();  break;
    default: return;
  }
  mtStop();
  lastMsg = 0;
}

#endif
