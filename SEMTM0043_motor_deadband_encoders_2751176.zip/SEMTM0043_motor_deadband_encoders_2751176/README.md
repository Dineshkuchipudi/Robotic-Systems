# SEMTM0043/42 – Motor deadband and wheel encoders (student 2751176)

Code and original data for my individual subsystem report:
*Subsystem characterisation: motor deadband and wheel encoders*.
Team task: path reproduction (StampC3 + Pololu 3pi+).

## Contents

| Folder / file | What it is |
|---|---|
| `arduino/StampC3_Template/Motortest.h` | Measurement code. Serial commands: `e` live encoder check, `d` deadband (start/stop PWM, lifted or floor), `r` counts per wheel revolution, `c` mm per count |
| `arduino/StampC3_Template/StampC3_Template.ino` | Template main sketch with the test mode switched on (`motorTestLoop(); return;` at the top of `loop()`) |
| `arduino/StampC3_Template/PathEvents.h` | Path-reproduction feedback: beeps every 10 cm of encoder distance (`robot.playTone`) and blinks the LED during turns (`robot.setLED`) |
| `arduino/StampC3_BeepTest/` | Stand-alone sketch to test the 10 cm beep and turn blink by pushing the robot by hand |
| `analysis/analyse_motors.py` | Processing: reads `motor_log.txt`, writes the figures, `data_*.csv` and `results_summary.txt` |
| `data/motor_log.txt` | **Original data**: complete Serial Monitor output of all trials |
| `data/data_*.csv`, `data/results_summary.txt` | Tables and summary derived from `motor_log.txt` by `analyse_motors.py` |
| `figures/` | Figure 1 (deadband and hysteresis) and Figure 2 (encoder counts per revolution) |

## How to use

**Robot code.** Copy the files from `arduino/StampC3_Template/` into the unit's
`StampC3_Template` sketch folder (it already contains `Robot.h`, `Robot.cpp`,
`Controller.*` and the other template files, which are not repeated here).
Board: M5StampC3, **USB CDC On Boot: Disabled**. Serial Monitor: 115200 baud,
"New Line". Type a test letter and press Enter.

**Analysis.**
```
pip install numpy matplotlib
cd data
python ../analysis/analyse_motors.py motor_log.txt
```

## Notes
- PWM values are in `setMotorPWM()` units.
- In test `r`, left-wheel trial 3 is excluded by the script: the right wheel
  was turned by mistake (visible in the raw log).
- `PE_MM_PER_COUNT` in `PathEvents.h` must be set to the measured mm per count
  (test `c`) before the beep is used.
